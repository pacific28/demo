package model

import (
	"time"

	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/mysql"
)

type Project struct {
	gorm.Model
	Title    string `gorm:"unique" json:"title"`
	Archived bool   `json:"archived"`
	Tasks    []Task `gorm:"ForeignKey:ProjectID" json:"tasks"`
}

func (p *Project) Archive() {
	p.Archived = true
}

func (p *Project) Restore() {
	p.Archived = false
}

type Task struct {
	gorm.Model
	Title     string     `json:"title"`
	Priority  string     `gorm:"type:ENUM('0', '1', '2', '3');default:'0'" json:"priority"`
	Deadline  *time.Time `gorm:"default:null" json:"deadline"`
	Done      bool       `json:"done"`
	ProjectID uint       `json:"project_id"`
}

func (t *Task) Complete() {
	t.Done = true
}

func (t *Task) Undo() {
	t.Done = false
}

type Newsreadapp struct {
	Uid           string          `json:"uid"`
	Time          string          `gorm:"default:null" json:"time"`
	News_duration []News_Duration `json:"news_duration"`
}

type News_Duration struct {
	New_id   string `json:"new_id"`
	Duration string `json:"duration"`
}

type Newsread struct {
	gorm.Model
	Uid   string `json:"uid"`
	Time  string `gorm:"default:null" json:"time"`
	Nid1  string `json:"nid1"`
	D1    string `json:"d1"`
	Nid2  string `json:"nid2"`
	D2    string `json:"d2"`
	Nid3  string `json:"nid3"`
	D3    string `json:"d3"`
	Nid4  string `json:"nid4"`
	D4    string `json:"d4"`
	Nid5  string `json:"nid5"`
	D5    string `json:"d5"`
	Nid6  string `json:"nid6"`
	D6    string `json:"d6"`
	Nid7  string `json:"nid7"`
	D7    string `json:"d7"`
	Nid8  string `json:"nid8"`
	D8    string `json:"d8"`
	Nid9  string `json:"nid9"`
	D9    string `json:"d9"`
	Nid10 string `json:"nid10"`
	D10   string `json:"d10"`
	Nid11 string `json:"nid11"`
	D11   string `json:"d11"`
	Nid12 string `json:"nid12"`
	D12   string `json:"d12"`
	Nid13 string `json:"nid13"`
	D13   string `json:"d13"`
	Nid14 string `json:"nid14"`
	D14   string `json:"d14"`
	Nid15 string `json:"nid15"`
	D15   string `json:"d15"`
	Nid16 string `json:"nid16"`
	D16   string `json:"d16"`
	Nid17 string `json:"nid17"`
	D17   string `json:"d17"`
	Nid18 string `json:"nid18"`
	D18   string `json:"d18"`
	Nid19 string `json:"nid19"`
	D19   string `json:"d19"`
	Nid20 string `json:"nid20"`
	D20   string `json:"d20"`
	Nid21 string `json:"nid21"`
	D21   string `json:"d21"`
	Nid22 string `json:"nid22"`
	D22   string `json:"d22"`
	Nid23 string `json:"nid23"`
	D23   string `json:"d23"`
	Nid24 string `json:"nid24"`
	D24   string `json:"d24"`
	Nid25 string `json:"nid25"`
	D25   string `json:"d25"`
	Nid26 string `json:"nid26"`
	D26   string `json:"d26"`
	Nid27 string `json:"nid27"`
	D27   string `json:"d27"`
	Nid28 string `json:"nid28"`
	D28   string `json:"d28"`
	Nid29 string `json:"nid29"`
	D29   string `json:"d29"`
	Nid30 string `json:"nid30"`
	D30   string `json:"d30"`
	Nid31 string `json:"nid31"`
	D31   string `json:"d31"`
	Nid32 string `json:"nid32"`
	D32   string `json:"d32"`
	Nid33 string `json:"nid33"`
	D33   string `json:"d33"`
	Nid34 string `json:"nid34"`
	D34   string `json:"d34"`
	Nid35 string `json:"nid35"`
	D35   string `json:"d35"`
	Nid36 string `json:"nid36"`
	D36   string `json:"d36"`
	Nid37 string `json:"nid37"`
	D37   string `json:"d37"`
	Nid38 string `json:"nid38"`
	D38   string `json:"d38"`
	Nid39 string `json:"nid39"`
	D39   string `json:"d39"`
	Nid40 string `json:"nid40"`
	D40   string `json:"d40"`
	Nid41 string `json:"nid41"`
	D41   string `json:"d41"`
	Nid42 string `json:"nid42"`
	D42   string `json:"d42"`
	Nid43 string `json:"nid43"`
	D43   string `json:"d43"`
	Nid44 string `json:"nid44"`
	D44   string `json:"d44"`
	Nid45 string `json:"nid45"`
	D45   string `json:"d45"`
	Nid46 string `json:"nid46"`
	D46   string `json:"d46"`
	Nid47 string `json:"nid47"`
	D47   string `json:"d47"`
	Nid48 string `json:"nid48"`
	D48   string `json:"d48"`
	Nid49 string `json:"nid49"`
	D49   string `json:"d49"`
	Nid50 string `json:"nid50"`
	D50   string `json:"d50"`
}

// DBMigrate will create and migrate the tables, and then make the some relationships if necessary
func DBMigrate(db *gorm.DB) *gorm.DB {
	db.AutoMigrate(&Project{}, &Task{}, &Newsread{})
	db.Model(&Task{}).AddForeignKey("project_id", "projects(id)", "CASCADE", "CASCADE")
	return db
}
