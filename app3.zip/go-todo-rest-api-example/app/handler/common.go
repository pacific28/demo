package handler

import (
	"encoding/json"
	"net/http"
)

type apiResponse struct {
	Status string `json:"status"`
}

// respondJSON makes the response with payload as json format
func respondJSON(w http.ResponseWriter, status int, payload interface{}) {
	_, err := json.Marshal(payload)
	outputjson := apiResponse{
		Status: "success",
	}
	s, _ := json.Marshal(outputjson)

	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	w.Write([]byte(s))
}

// respondError makes the error response with payload as json format
func respondError(w http.ResponseWriter, code int, message string) {
	respondJSON(w, code, map[string]string{"error": message})
}
