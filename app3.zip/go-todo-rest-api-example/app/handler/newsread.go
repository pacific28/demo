package handler

import (
	"encoding/json"
	"fmt"

	"net/http"

	"github.com/gorilla/mux"
	"github.com/jinzhu/gorm"
	"github.com/mingrammer/go-todo-rest-api-example/app/model"
)

func GetAllNewsreads(db *gorm.DB, w http.ResponseWriter, r *http.Request) {
	newsreads := []model.Newsread{}
	db.Find(&newsreads)
	respondJSON(w, http.StatusOK, newsreads)
}

func CreateNewsread(db *gorm.DB, w http.ResponseWriter, r *http.Request) {
	newsreadapp := model.Newsreadapp{}
	dec := json.NewDecoder(r.Body)
	err := dec.Decode(&newsreadapp)
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()
	nd := newsreadapp.News_duration
	fmt.Println("Newsread Data=====", nd)
	var arr []string
	for a := 0; a < len(nd); a++ {
		arr = append(arr, nd[a].New_id)
		arr = append(arr, nd[a].Duration)
	}
	arrLen := len(arr)
	if arrLen < 104 {
		for b := 0; b < 50; b++ {
			arr = append(arr, "0")
			arr = append(arr, "00")
		}
	}

	it := model.Newsread{}
	it.Uid = newsreadapp.Uid
	it.Time = newsreadapp.Time
	it.Nid1 = arr[0]
	it.D1 = arr[1]
	it.Nid2 = arr[2]
	it.D2 = arr[3]
	it.Nid3 = arr[4]
	it.D3 = arr[5]
	it.Nid4 = arr[6]
	it.D4 = arr[7]
	it.Nid5 = arr[8]
	it.D5 = arr[9]
	it.Nid5 = arr[10]
	it.D5 = arr[11]
	it.Nid6 = arr[12]
	it.D6 = arr[13]
	it.Nid7 = arr[14]
	it.D7 = arr[15]
	it.Nid8 = arr[16]
	it.D8 = arr[17]
	it.Nid9 = arr[18]
	it.D9 = arr[19]
	it.Nid10 = arr[20]
	it.D10 = arr[21]
	it.Nid11 = arr[22]
	it.D11 = arr[23]
	it.Nid12 = arr[24]
	it.D12 = arr[25]
	it.Nid13 = arr[26]
	it.D13 = arr[27]
	it.Nid14 = arr[28]
	it.D14 = arr[29]
	it.Nid15 = arr[30]
	it.D15 = arr[31]
	it.Nid16 = arr[32]
	it.D16 = arr[33]
	it.Nid17 = arr[34]
	it.D17 = arr[35]
	it.Nid18 = arr[36]
	it.D18 = arr[37]
	it.Nid19 = arr[38]
	it.D19 = arr[39]
	it.Nid20 = arr[40]
	it.D20 = arr[41]
	it.Nid21 = arr[42]
	it.D21 = arr[43]
	it.Nid22 = arr[44]
	it.D22 = arr[45]
	it.Nid23 = arr[46]
	it.D23 = arr[47]
	it.Nid24 = arr[48]
	it.D24 = arr[49]
	it.Nid25 = arr[50]
	it.D25 = arr[51]
	it.Nid26 = arr[52]
	it.D26 = arr[53]
	it.Nid27 = arr[54]
	it.D27 = arr[55]
	it.Nid28 = arr[56]
	it.D28 = arr[57]
	it.Nid29 = arr[58]
	it.D29 = arr[59]
	it.Nid30 = arr[60]
	it.D30 = arr[61]
	it.Nid31 = arr[62]
	it.D31 = arr[63]
	it.Nid32 = arr[64]
	it.D32 = arr[65]
	it.Nid33 = arr[66]
	it.D33 = arr[67]
	it.Nid34 = arr[68]
	it.D34 = arr[69]
	it.Nid35 = arr[70]
	it.D35 = arr[71]
	it.Nid36 = arr[72]
	it.D36 = arr[73]
	it.Nid37 = arr[74]
	it.D37 = arr[75]
	it.Nid38 = arr[76]
	it.D38 = arr[77]
	it.Nid39 = arr[78]
	it.D39 = arr[79]
	it.Nid40 = arr[80]
	it.D40 = arr[81]
	it.Nid41 = arr[82]
	it.D41 = arr[83]
	it.Nid42 = arr[84]
	it.D42 = arr[85]
	it.Nid43 = arr[86]
	it.D43 = arr[87]
	it.Nid44 = arr[88]
	it.D44 = arr[89]
	it.Nid45 = arr[90]
	it.D45 = arr[91]
	it.Nid46 = arr[92]
	it.D46 = arr[93]
	it.Nid47 = arr[94]
	it.D47 = arr[95]
	it.Nid48 = arr[96]
	it.D48 = arr[97]
	it.Nid49 = arr[98]
	it.D49 = arr[99]
	it.Nid50 = arr[100]
	it.D50 = arr[101]
	fmt.Println(it)

	if err := db.Save(&it).Error; err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusCreated, it)
}

func GetNewsread(db *gorm.DB, w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)

	uid := vars["uid"]
	newsread := getNewsreadOr404(db, uid, w, r)
	if newsread == nil {
		return
	}
	respondJSON(w, http.StatusOK, newsread)
}

// getNewsreadOr404 gets a project instance if exists, or respond the 404 error otherwise
func getNewsreadOr404(db *gorm.DB, uid string, w http.ResponseWriter, r *http.Request) *model.Newsread {
	newsread := model.Newsread{}
	if err := db.First(&newsread, model.Newsread{Uid: uid}).Error; err != nil {
		respondError(w, http.StatusNotFound, err.Error())
		return nil
	}
	return &newsread
}
